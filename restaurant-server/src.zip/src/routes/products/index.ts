import express from 'express';
import { data } from "./../../../src/data/food-items";

const router = express.Router();

//creating controaller
router.get('/list',(req: any, res: any, next:any)=>{
    try {
        const resp={
            data:data
        };
        res.json(resp);
    } catch (err) {
        next(err);
    }
})

export default router;
